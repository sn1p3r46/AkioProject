The iPython history scripts included in this folder were used to automatize the Risk Prioritization ranking using the AHP technique. They contain the list of commands that were used to rank the risks. With little further development they could be turned into a program, however, they are presented as is, in case the reader is interested in knowing how the results presented in the report were obtained.

No warranty is provided. This script is released without license. The reader is free to use the code for any purposes without need for attribution.

6.June.2015
